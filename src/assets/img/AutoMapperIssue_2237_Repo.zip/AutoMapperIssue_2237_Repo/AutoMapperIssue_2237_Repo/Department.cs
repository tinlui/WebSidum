﻿using System.Collections.Generic;

namespace AutoMapperIssue_2237_Repo
{
    public sealed class Department : EntityId
    {
        public string Name { get; private set; }
        public string Description { get; private set; }
        public ICollection<Position> Positions { get; } = new List<Position>();

        private Department()
        {
            Positions = new List<Position>();
        }

        public static Department Create(string name, string description)
        {
            return new Department
            {
                Name = name,
                Description = description,
            };
        }
    }
}