﻿namespace AutoMapperIssue_2237_Repo
{
    public sealed class Position : EntityId
    {
        public string Name { get; private set; }
        public string Description { get; private set; }

        public long DepartmentID { get; private set; }
        public Department Department { get; private set; }

        private Position()
        {
        }

        public static Position Create(string name, string description)
        {
            return new Position
            {
                Name = name,
                Description = description
            };
        }
    }
}