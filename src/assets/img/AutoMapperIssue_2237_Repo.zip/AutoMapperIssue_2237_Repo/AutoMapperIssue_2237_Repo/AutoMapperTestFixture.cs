﻿using AutoMapper;
using System;
using System.Collections.Generic;

namespace AutoMapperIssue_2237_Repo
{
    public class AutoMapperTestFixture : IDisposable
    {
        private bool disposedValue = false; // To detect redundant calls
        public IMapper Mapper { get; }

        public IEnumerable<Department> Departments { get; }

        public AutoMapperTestFixture()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<HRModelMappingProfile>();
            });

            Mapper = config.CreateMapper();

            Departments = GetTestDepartmentList();
        }

        private IEnumerable<Department> GetTestDepartmentList()
        {
            var d1 = Department.Create(name: Guid.NewGuid().ToString(), description: Guid.NewGuid().ToString());
            d1.Positions.Add(Position.Create(name: Guid.NewGuid().ToString(), description: Guid.NewGuid().ToString()));
            d1.Positions.Add(Position.Create(name: Guid.NewGuid().ToString(), description: Guid.NewGuid().ToString()));
            d1.Positions.Add(Position.Create(name: Guid.NewGuid().ToString(), description: Guid.NewGuid().ToString()));

            var d2 = Department.Create(name: Guid.NewGuid().ToString(), description: Guid.NewGuid().ToString());
            d2.Positions.Add(Position.Create(name: Guid.NewGuid().ToString(), description: Guid.NewGuid().ToString()));
            d2.Positions.Add(Position.Create(name: Guid.NewGuid().ToString(), description: Guid.NewGuid().ToString()));

            var d3 = Department.Create(name: Guid.NewGuid().ToString(), description: Guid.NewGuid().ToString());
            d3.Positions.Add(Position.Create(name: Guid.NewGuid().ToString(), description: Guid.NewGuid().ToString()));

            var departments = new Department[] { d1, d2, d3 };
            return departments;
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~AutoMapperTestFixture() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }
    }
}