﻿using System.Collections.Generic;

namespace AutoMapperIssue_2237_Repo
{
    public class DepartmentDto : DepartmentWithoutPositionsDto
    {
        public int NumberOfPositions
        {
            get
            {
                return Positions.Count;
            }
        }

        public ICollection<PositionDto> Positions { get; set; } = new List<PositionDto>();
    }
}