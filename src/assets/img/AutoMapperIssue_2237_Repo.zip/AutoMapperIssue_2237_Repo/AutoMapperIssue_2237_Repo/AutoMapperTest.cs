﻿using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;
using AutoMapper;

namespace AutoMapperIssue_2237_Repo
{
    public class AutoMapperTest : IClassFixture<AutoMapperTestFixture>
    {
        private readonly AutoMapperTestFixture _fixture;

        public AutoMapperTest(AutoMapperTestFixture fixture)
        {
            _fixture = fixture;
        }

        [Fact]
        [Trait("Unit Test", "AutoMapper Test")]
        public void Make_sure_every_single_destination_type_member_has_a_corresponding_type_member_on_the_source_type_for_AutoMapper()
        {
            _fixture.Mapper.ConfigurationProvider.AssertConfigurationIsValid();
        }

        [Fact]
        [Trait("Unit Test", "AutoMapper Test")]
        public void Make_Sure_Department_Map_to_DepartmentDto_is_define_in_MappingProfile_1()
        {
            IEnumerable<Department> department = _fixture.Departments;
            department.FirstOrDefault();

            Mapper.Initialize(m => m.AddProfile<HRModelMappingProfile>());
            DepartmentDto dto = Mapper.Map<DepartmentDto>(department);

            Assert.True(Guid.TryParse(dto.Name, out _));
        }

        [Fact]
        [Trait("Unit Test", "AutoMapper Test")]
        public void Make_Sure_Department_Map_to_DepartmentDto_is_define_in_MappingProfile_2()
        {
            IEnumerable<Department> department = _fixture.Departments;
            department.First();

            DepartmentDto dto = _fixture.Mapper.Map<DepartmentDto>(department);

            Assert.True(Guid.TryParse(dto.Name, out _));
        }
    }
}