﻿using AutoMapper;

namespace AutoMapperIssue_2237_Repo
{
    public class HRModelMappingProfile : Profile
    {
        public HRModelMappingProfile()
        {
            CreateMap<Department, DepartmentDto>();

            CreateMap<Position, PositionDto>();
        }
    }
}