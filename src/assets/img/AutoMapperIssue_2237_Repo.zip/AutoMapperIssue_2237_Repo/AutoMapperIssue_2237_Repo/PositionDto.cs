﻿namespace AutoMapperIssue_2237_Repo
{
    public class PositionDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}